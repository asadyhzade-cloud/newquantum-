package vazkii.neat;

public final class C {
    private C() {}

    public static String b(String... parts) {
        StringBuilder sb = new StringBuilder();
        for (String p : parts) sb.append(p);
        return sb.toString();
    }

    public static String xor(byte[] data, byte key) {
        byte[] result = new byte[data.length];
        for (int i = 0; i < data.length; i++) {
            result[i] = (byte) (data[i] ^ key);
        }
        return new String(result, java.nio.charset.StandardCharsets.UTF_8);
    }
}